package com.example.securingwebinitial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecuringWebInitialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecuringWebInitialApplication.class, args);
	}

}
